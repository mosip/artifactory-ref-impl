#!/bin/bash
cat ref.softhsm
cat ref.proxy
mkdir -p /usr/local/lib/softhsm/
mkdir -p /config/
cp libpkcs11-proxy.so.0.1 /usr/local/lib/softhsm/libpkcs11-proxy.so
cp pkcs11.cfg /config/softhsm-application.conf
