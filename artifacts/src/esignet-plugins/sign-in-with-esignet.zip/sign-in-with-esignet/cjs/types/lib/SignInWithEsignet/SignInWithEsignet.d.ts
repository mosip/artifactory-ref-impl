import { ISignInWithEsignetProps } from "./ISignInWithEsignetProps";
declare const SignInWithEsignet: ({ ...props }: ISignInWithEsignetProps) => HTMLElement;
export default SignInWithEsignet;
