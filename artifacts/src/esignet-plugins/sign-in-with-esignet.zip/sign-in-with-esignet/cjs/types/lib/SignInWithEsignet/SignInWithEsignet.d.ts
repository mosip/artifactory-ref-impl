import { ISignInWithEsignetProps } from "./ISignInWithEsignetProps";
declare const init: ({ ...props }: ISignInWithEsignetProps) => HTMLElement;
export default init;
