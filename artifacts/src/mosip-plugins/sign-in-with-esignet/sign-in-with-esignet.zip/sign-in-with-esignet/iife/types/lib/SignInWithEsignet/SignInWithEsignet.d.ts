import { ISignInWithEsignetProps } from "./ISignInWithEsignetProps";
declare const init: ({ ...props }: ISignInWithEsignetProps) => Promise<HTMLElement>;
export default init;
