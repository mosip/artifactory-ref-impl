#!/bin/bash

#installs the Bio-SDK
set -e

echo "Installating Mock Bio-SDK.."

mv biosdk-client-*.jar $loader_path_env

echo "Installating Mock Bio-SDK completed."
